﻿using System;

namespace SumOf3
{
    class Program
    {
        const double LUCKY_NUMBER = 7.777;
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
